import { Inject, Injectable, NotFoundException } from "@nestjs/common";
import { Prisma } from "@prisma/client";

import { PrismaService } from "../prisma/prisma.service";

export type RoommateActionValue = "LIKE" | "PASS" | "LATER";

type RecordRoommateActionInput = {
  userId: string;
  roommateProfileId: string;
  action: RoommateActionValue;
  createDealRoom?: boolean;
};

type RoommateSnapshot = {
  id: string;
  name: string;
  age: number;
  role: string;
  image: string;
  match: number;
  budget: string;
  commute: string;
  tags: string[];
};

type ListingSnapshot = {
  id: string;
  title: string;
  area: string;
  image: string | null;
  price: number;
  beds: number;
  baths: number;
  commute: string;
  trust: string;
  tags: string[];
  fitLabel: "Best match" | "Strong fit" | "Worth comparing";
};

@Injectable()
export class DealRoomsService {
  constructor(@Inject(PrismaService) private readonly prisma: PrismaService) {}

  async recordRoommateAction(input: RecordRoommateActionInput) {
    const roommate = await this.resolveRoommateProfile(input.roommateProfileId);
    const action = await this.prisma.roommateAction.upsert({
      where: {
        userId_roommateProfileId: {
          userId: input.userId,
          roommateProfileId: roommate.id
        }
      },
      create: {
        userId: input.userId,
        roommateProfileId: roommate.id,
        action: input.action
      },
      update: {
        action: input.action
      }
    });

    return {
      action,
      dealRoom: null
    };
  }

  async ensureForConfirmedTeam(
    transaction: Prisma.TransactionClient,
    ownerId: string,
    teammateId: string
  ) {
    if (ownerId === teammateId) throw new NotFoundException("Roommate profiles not found");

    const profiles = await transaction.roommateProfile.findMany({
      where: { ownerId: { in: [ownerId, teammateId] } }
    });
    const ownerProfile = profiles.find((profile) => profile.ownerId === ownerId);
    const teammateProfile = profiles.find((profile) => profile.ownerId === teammateId);
    if (!ownerProfile || !teammateProfile) throw new NotFoundException("Roommate profiles not found");

    const existing = await transaction.dealRoom.findFirst({
      where: {
        status: "ACTIVE",
        OR: [
          { ownerId, roommateProfileId: teammateProfile.id },
          { ownerId: teammateId, roommateProfileId: ownerProfile.id }
        ]
      }
    });
    const room = existing ?? await transaction.dealRoom.create({
      data: {
        ownerId,
        roommateProfileId: teammateProfile.id,
        status: "ACTIVE",
        recommendedHomes: await this.buildRecommendedHomes(transaction, teammateProfile),
        pipeline: [
          { label: "Match", status: "active", detail: "Team confirmed" },
          { label: "Shortlist", status: "ready", detail: "Ready to compare" },
          { label: "Tour", status: "ready", detail: "Ready to schedule" },
          { label: "Apply", status: "idle", detail: "Not started" }
        ],
        trustChecklist: [
          { label: "Profile", detail: "Both profiles confirmed", complete: true },
          { label: "Team", detail: "Two-person team confirmed", complete: true }
        ]
      }
    });

    await Promise.all(
      [ownerProfile, teammateProfile].map((profile) =>
        transaction.dealRoomMember.upsert({
          where: {
            dealRoomId_roommateProfileId: {
              dealRoomId: room.id,
              roommateProfileId: profile.id
            }
          },
          create: {
            dealRoomId: room.id,
            roommateProfileId: profile.id,
            snapshot: this.toRoommateSnapshot(profile)
          },
          update: {
            snapshot: this.toRoommateSnapshot(profile)
          }
        })
      )
    );

    return room;
  }

  async findActiveForUser(userId: string) {
    const rooms = await this.prisma.dealRoom.findMany({
      where: {
        ownerId: userId,
        status: "ACTIVE"
      },
      include: {
        members: true,
        tourRequest: true
      },
      orderBy: {
        updatedAt: "desc"
      }
    });

    return rooms.map((room) => this.toDealRoomResponse(room));
  }

  async requestGroupTour(userId: string, dealRoomId: string) {
    const room = await this.prisma.dealRoom.findFirst({
      where: {
        id: dealRoomId,
        ownerId: userId,
        status: "ACTIVE"
      }
    });

    if (!room) throw new NotFoundException("Deal room not found");

    return this.prisma.$transaction(async (transaction) => {
      // Recheck after acquiring the room lock: dissolution may have archived it
      // since the initial authorization read. Hold it through the tour insert.
      const active = await transaction.dealRoom.updateMany({
        where: { id: dealRoomId, ownerId: userId, status: "ACTIVE" },
        data: { status: "ACTIVE" }
      });
      if (active.count !== 1) throw new NotFoundException("Deal room not found");
      return transaction.tourRequest.upsert({
        where: { dealRoomId },
        create: { dealRoomId, requesterId: userId, status: "REQUESTED" },
        update: {}
      });
    });
  }

  private async resolveRoommateProfile(id: string): Promise<RoommateSnapshot> {
    const record = await this.prisma.roommateProfile.findUnique({ where: { id } });
    if (record) return this.toRoommateSnapshot(record);

    throw new NotFoundException("Roommate profile not found");
  }

  private async buildRecommendedHomes(
    transaction: Prisma.TransactionClient,
    roommate: RoommateSnapshot
  ): Promise<ListingSnapshot[]> {
    const records = await transaction.listing.findMany({
      where: {
        status: "APPROVED"
      },
      orderBy: {
        score: "desc"
      },
      take: 6
    });
    const roommateTokens = getTokens(roommate.commute);

    return records
      .map((listing) => {
        const listingTokens = getTokens(`${listing.area} ${listing.commute} ${listing.transit}`);
        const overlap = roommateTokens.filter((token) => listingTokens.includes(token)).length;
        const groupFit = listing.tags.some((tag) => tag.includes("Group")) || listing.beds > 1 ? 1 : 0;
        const trustFit = listing.trust.includes("认证") || listing.trust.toLowerCase().includes("verified") ? 1 : 0;
        const fitScore = overlap * 20 + groupFit * 12 + trustFit * 10 + listing.score * 10;

        const fitLabel = getFitLabel(fitScore);

        return {
          id: listing.id,
          title: listing.title,
          area: listing.area,
          image: listing.image,
          price: listing.price,
          beds: listing.beds,
          baths: listing.baths,
          commute: listing.commute,
          trust: listing.trust,
          tags: listing.tags,
          fitLabel,
          fitScore
        };
      })
      .sort((a, b) => b.fitScore - a.fitScore || a.price - b.price)
      .slice(0, 3)
      .map(({ fitScore: _fitScore, ...listing }) => listing);
  }

  private toDealRoomResponse(room: any) {
    return {
      ...room,
      canRequestTour: room.status === "ACTIVE"
    };
  }

  private toRoommateSnapshot(roommate: RoommateSnapshot): RoommateSnapshot {
    return {
      id: roommate.id,
      name: roommate.name,
      age: roommate.age,
      role: roommate.role,
      image: roommate.image,
      match: roommate.match,
      budget: roommate.budget,
      commute: roommate.commute,
      tags: roommate.tags
    };
  }
}

function getTokens(value: string) {
  return value
    .toLowerCase()
    .split(/[^a-z0-9\u4e00-\u9fa5]+/i)
    .filter((token) => token.length >= 2);
}

function getFitLabel(score: number): ListingSnapshot["fitLabel"] {
  if (score >= 70) return "Best match";
  if (score >= 55) return "Strong fit";
  return "Worth comparing";
}
